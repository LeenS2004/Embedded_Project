#define FORWARD_LINE       62
#define FORWARD_OBSTACLE   80
#define IN_TUNNEL          100
#define RIGHT_ADD          5
#define TURN_FORWARD       42
#define STOP               0

#define IR_FAST_TURN       29

#define LIGHT_THRESHOLD    350
#define OBSTACLE_DISTANCE  43
#define TIMEOUT_COUNT      30000UL // Timeout for ultrasonic echo

#define BUZZER_ON   PORTB |= 0x04
#define BUZZER_OFF  PORTB &= 0xFB

/* ================= TIMER0 DELAY ================= */

unsigned char t0_overflows = 0;    // Counts Timer0 overflows

void timer0_init()
{
    OPTION_REG &= 0xDF;   // Use internal clock for Timer0
    OPTION_REG &= 0xF7;   // Assign prescaler to Timer0
    OPTION_REG |= 0x07;   // Set prescaler to 1:256

    TMR0 = 0;             // Clear Timer0
    INTCON &= 0xFB;       // Clear Timer0 overflow flag
}

void delay_ms(unsigned int ms)
{
    unsigned int target;  // Required number of overflows

    target = ms / 51;     // Approximate ms per overflow at 8 MHz
    if (target == 0) target = 1; // Ensure at least one overflow

    t0_overflows = 0;     // Reset overflow counter
    TMR0 = 0;             // Reset Timer0
    INTCON &= 0xFB;       // Clear overflow flag

    while (t0_overflows < target) // Wait until desired delay is reached
    {
        if (INTCON & 0x04)        // Check if Timer0 overflow occurred
        {
            INTCON &= 0xFB;       // Clear overflow flag
            t0_overflows++;      // Count overflow
        }
    }
}

/* ================= MICRO DELAY ================= */

void delay_us(unsigned int us)
{
    unsigned int i;
    while (us--)
        for (i = 0; i < 5; i++);
}

/* ================= PWM SETUP ================= */

void pwm_init()
{
    TRISC = 0x18;   // Set RC3 and RC4 as inputs (IR sensors)
    T2CON = 0x07;   // Enable Timer2 with prescaler
    PR2   = 249;    // PWM period setup

    CCP1CON = 0x0C; // Enable PWM for left motor
    CCP2CON = 0x0C; // Enable PWM for right motor

    CCPR1L = 0;     // Left motor OFF
    CCPR2L = 0;     // Right motor OFF
}

/* ================= ADC SETUP ================= */

void adc_init()
{
    ADCON1 = 0x80;  // Right justify result, Vref = Vdd
    ADCON0 = 0x41;  // Enable ADC, select channel 0
}

unsigned int read_adc()
{
    ADCON0 |= 0x04;                     // Start ADC conversion
    while (ADCON0 & 0x04);              // Wait until conversion finishes
    return ((ADRESH << 8) + ADRESL);    // Return 10-bit ADC result
}

/* ================= ULTRASONIC READ ================= */

unsigned int ultrasonic_read()
{
    unsigned long time = 0;             // Store echo time

    PORTD &= 0xFB;                      // Trigger LOW
    delay_us(2);                        // Short delay
    PORTD |= 0x04;                      // Trigger HIGH
    delay_us(15);                       // 15 us pulse
    PORTD &= 0xFB;                      // Trigger LOW

    T1CON = 0x00;                       // Stop Timer1
    TMR1H = 0;                          // Clear Timer1 high byte
    TMR1L = 0;                          // Clear Timer1 low byte
    T1CON = 0x01;                       // Start Timer1

    while (!(PORTD & 0x08))             // Wait for echo HIGH
    {
        time = ((unsigned long)TMR1H << 8) | TMR1L;
        if (time > TIMEOUT_COUNT)       // Timeout protection
        {
            T1CON = 0;
            return 0;
        }
    }

    TMR1H = 0;                          // Reset Timer1
    TMR1L = 0;

    while (PORTD & 0x08)                // Measure echo HIGH time
    {
        time = ((unsigned long)TMR1H << 8) | TMR1L;
        if (time > TIMEOUT_COUNT)
        {
            T1CON = 0;
            return 0;
        }
    }

    T1CON = 0;                          // Stop Timer1
    time = ((unsigned long)TMR1H << 8) | TMR1L;

    return (time / 58);                 // Convert time to distance (cm)
}

/* ================= MOTOR MOVES ================= */

void forward_line()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = FORWARD_LINE;
    CCPR2L = FORWARD_LINE + RIGHT_ADD;
}

void forward_obstacle()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = FORWARD_OBSTACLE;
    CCPR2L = FORWARD_OBSTACLE + RIGHT_ADD;
}

void in_tunnel()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = IN_TUNNEL;
    CCPR2L = IN_TUNNEL + RIGHT_ADD;
}

void slight_left()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = STOP;
    CCPR2L = TURN_FORWARD + RIGHT_ADD;
}

void slight_right()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = TURN_FORWARD;
    CCPR2L = STOP;
}

void hard_left()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = STOP;
    CCPR2L = STOP;
    delay_ms(300);
    CCPR1L = STOP;
    CCPR2L = 65;
    delay_ms(580);
}

void hard_right()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = STOP;
    CCPR2L = STOP;
    delay_ms(100);
    CCPR1L = 70;
    CCPR2L = STOP;
    delay_ms(15);
}

void stop()
{
    CCPR1L = STOP;
    CCPR2L = STOP;
    PORTB &= 0x04;
}

void IR_left()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = STOP;
    CCPR2L = IR_FAST_TURN + RIGHT_ADD;
}

void IR_right()
{
    PORTB = (PORTB & 0x04) | 0x11;
    CCPR1L = IR_FAST_TURN;
    CCPR2L = STOP;
}

void IR_spin_escape()
{
    PORTB = (PORTB & 0x04) | 0x11;

    CCPR1L = IR_FAST_TURN + 15;
    CCPR2L = STOP;
    delay_ms(500);

    CCPR1L = STOP;
    CCPR2L = STOP;
    delay_ms(200);
}

/* ================= SERVO CONTROL (RC6) ================= */

void servo_flag()
{
    unsigned char i;

    for (i = 0; i < 40; i++)            // Generate servo pulses
    {
        PORTC |= 0x40;                  // Servo HIGH
        delay_us(1500);                 // Pulse width (~90 degrees)
        PORTC &= 0xBF;                  // Servo LOW
        delay_us(18500);                // Complete 20ms period
    }
}

void beep_once()
{
    BUZZER_ON;
    delay_ms(250);
    BUZZER_OFF;
    delay_ms(250);
}

/* ================= MAIN ================= */

void main()
{
    unsigned char sensors;
    unsigned int  light;
    unsigned int  distance;
    unsigned char ultrasonic_latched = 0;
    unsigned char parked = 0;
    unsigned char flag_raised = 0;

    TRISD = 0x6B;
    TRISB = 0x00;
    TRISA = 0x01;
    TRISC &= 0xBF;

    PORTC &= 0xBF;
    PORTB = 0x00;
    PORTD = 0x00;
    PORTC = 0x00;

    pwm_init();
    adc_init();
    timer0_init();

    /* ===== START ZONE (MCLR RESET BUTTON) ===== */
    stop();
    PORTD &= 0x7F;
    delay_ms(3000);
    PORTD |= 0x80;

    OPTION_REG &= 0xDF;                   // Ensure internal clock for Timer0

    while (1)
    {
        light = read_adc();
        if (light > LIGHT_THRESHOLD)
        {
            PORTB = (PORTB & 0x04) | 0x11;
            switch (sensors)
            {
            case 0x03: in_tunnel();        break;
            case 0x02: slight_left();      break;
            case 0x01: slight_right();     break;
            }
            ultrasonic_latched = 1;
            PORTB |= 0x04;                // Turn buzzer ON inside tunnel
        }
        else
            PORTB &= 0xFB;                // Turn buzzer OFF outside tunnel

        distance = ultrasonic_read();

        if (distance > 0 && distance <= OBSTACLE_DISTANCE &&
            !(PORTC & 0x10) && !(PORTC & 0x08) && ultrasonic_latched == 1)
        {
            PORTD |= 0x10;                // Indicate obstacle detected
            IR_spin_escape();
            continue;
        }

        if (!(PORTC & 0x10) && (PORTC & 0x08) && ultrasonic_latched == 1)
        {
            IR_right();
            continue;
        }
        else if (!(PORTC & 0x08) && (PORTC & 0x10) && ultrasonic_latched == 1)
        {
            IR_left();
            continue;
        }
        else if (!(PORTC & 0x18) && ultrasonic_latched == 1)
        {
            forward_obstacle();
            continue;
        }

        if (!(PORTD & 0x20) && (PORTD & 0x40) && ultrasonic_latched == 1)
        {
            IR_right();
            continue;
        }
        else if (!(PORTD & 0x40) && (PORTD & 0x20) && ultrasonic_latched == 1)
        {
            IR_left();
            continue;
        }

        if (distance > 0 && distance <= OBSTACLE_DISTANCE && ultrasonic_latched == 1)
        {
            PORTD |= 0x10;
            IR_spin_escape();
            continue;
        }
        else
        {
            PORTD &= 0xEF;
        }

        sensors = PORTD & 0x03;
        switch (sensors)
        {
            case 0x03: forward_line(); break;
            case 0x02: slight_left();  break;
            case 0x01: slight_right(); break;
            case 0x00:
              if (ultrasonic_latched == 1 && parked == 0)
              {
                  forward_line();
                  beep_once();

                  delay_ms(70);

                  hard_right();
                  beep_once();

                  stop();
                  beep_once();

                  parked = 1;

                  if (flag_raised == 0)
                  {
                      beep_once();
                      PORTD &= 0x7F;
                      servo_flag();
                      flag_raised = 1;
                  }

                  BUZZER_OFF;
              }
              else if (parked == 1)
              {
                  stop();                  // Stay parked forever
              }
              else
              {
                  hard_left();
              }
              break;
        }
    }
}